import dynamic from "next/dynamic";
import { Inter } from "next/font/google";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import {
    IoBarChartSharp,
    IoCard,
    IoDocument,
    IoPricetag,
    IoStatsChart,
    IoWallet
} from "react-icons/io5";

import Container from "@/components/Container";
import PaymentsBar from "@/components/PaymentsBar";
import Sidebar from "@/components/Sidebar";
import TopBar from "@/components/TopBar";
import { Api } from "@/api/apiDashboard";

const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

const inter = Inter({
    weight: ["300", "400", "500", "600", "700", "900"],
    subsets: ["latin"]
});

const DashboardPage = () => {
    const [valorLiquido,setValorLiquido] = useState(0)
    const [vendasDiarias,setVendasDiarias] = useState(0)
    const [taxaAprovacaoCartao,setTaxaAprovacaoCartao] = useState(0)
    const [boletosGerados,setBoletosGerados] = useState(0)
    const [taxaAprovacaoBoleto,setTaxaAprovacaoBoleto] = useState(0)
    const [cartao,setCartao] = useState(0)
    const [boleto,setBoleto] = useState(0)
    const [pix,setPix] = useState(0)
    const [vendasAnuais,setVendasAnuais] = useState([])
    const [valorTotal,setValorTotal] = useState(0)
    const [plataforma,setPlataforma] = useState(0)
    useEffect(()=>{
        handleDados()
    },[])
    const handleDados = async () =>{
        let response = await Api.Dados()
        if(!response.error){
            setValorLiquido(response.valorLiquido)
            setVendasDiarias(response.vendasDiarias)
            setTaxaAprovacaoCartao(response.taxaAprovacaoCartao)
            setBoletosGerados(response.boleto)
            setTaxaAprovacaoBoleto(response.taxaAprovacaoBoleto)
            setCartao(response.cartao)
            setBoleto(response.cartao)
            setPix(response.cartao)
            setPlataforma(response.plataforma)
            let vendas = response.vendaAnuais.map((item)=>{return item.total_vendas})
            let valorTotal = vendas.reduce((acumulador,elemet)=>{return acumulador + elemet},0)
            setVendasAnuais(vendas)
            setValorTotal(valorTotal)
        }
    }
   
    const formatValue = (value) => {
        if (value >= 1000) {
            const inK = Math.floor(value / 1000);
            return `R$ ${inK}k`;
        } else {
            return `R$ ${value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,")}`;
        }
    };

    const optionsLine = {
        chart: {
            height: 300,
            type: "line",
            zoom: {
                enabled: false
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: "straight"
        },
        colors: ["#3765AE"],
        xaxis: {
            labels: {
                show: false
            },
            categories: [
                "01 Out 00:00",
                "02 Out 10:00",
                "04 Out 04:00",
                "06 Out 20:00",
                "13 Out 00:10",
                "14 Out 06:00",
                "19 Out 00:00",
                "25 Out 10:00",
                "29 Out 07:00",
                "30 Out 09:00"
            ]
        },
        yaxis: {
            labels: {
                formatter: function (value) {
                    return formatValue(value);
                }
            }
        }
    };

    const seriesLine = [
        {
            name: "Vendas",
            data: vendasAnuais
        }
    ];

    const optionsDonut = {
        chart: {
            type: "donut"
        },
        plotOptions: {
            pie: {
                startAngle: -90,
                endAngle: 90,
                offsetY: 10
            }
        },
        grid: {
            padding: {
                bottom: -200
            }
        },
        legend: {
            position: "bottom",
            labels: {
                colors: "#616F81"
            }
        },
        responsive: [
            {
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: "bottom"
                    },
                    grid: {
                        padding: {
                            bottom: -80
                        }
                    }
                }
            }
        ],
        labels: ["Recorrentes", "Novos"],
        colors: ["#5660B0", "#50B795"]
    };

    const seriesDonut = [0, 0];

    return (
        <div className="flex">
            <Sidebar />
            <Container>
                <TopBar notRegistered pageTitle="Dashboard" />
                <div className="dark:bg-black-600 p-5 lg:px-11 flex flex-col gap-9 lg:flex-row">
                    <div className="flex flex-1 flex-col gap-8">
                        <div className="px-8 py-3 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex flex-col gap-12">
                            <h3
                                className={`${inter.className} text-xl font-bold dark:text-white-400`}
                            >
                                Métodos de pagamento
                            </h3>
                            <PaymentsBar credit={cartao} pix={pix} bill={boleto} />
                            <div className="flex items-center gap-5 lg:gap-16">
                                <div className="flex items-center gap-2">
                                    <div className="w-4 h-4 rounded-[50%] bg-secondary-500"></div>
                                    <p
                                        className={`${inter.className} text-sm font-normal text-gray-text`}
                                    >
                                        Cartão
                                    </p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-4 h-4 rounded-[50%] bg-primary-400"></div>
                                    <p
                                        className={`${inter.className} text-sm font-normal text-gray-text`}
                                    >
                                        PIX
                                    </p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <div className="w-4 h-4 rounded-[50%] bg-gray-bar"></div>
                                    <p
                                        className={`${inter.className} text-sm font-normal text-gray-text`}
                                    >
                                        Boleto
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="p-4 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex items-center gap-6">
                            <IoWallet
                                size={20}
                                className="text-dashboard-icon"
                            />
                            <div className="flex flex-col gap-1">
                                <h3
                                    className={`${inter.className} text-sm font-semibold text-dashboard-title`}
                                >
                                    Valor líquido
                                </h3>
                                <p
                                    className={`${inter.className} text-lg font-bold text-black-400 dark:text-white-400`}
                                >
                                    {(plataforma?plataforma:valorLiquido)?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                </p>
                            </div>
                        </div>
                        <div className="p-4 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex items-center gap-6">
                            <IoBarChartSharp
                                size={20}
                                className="text-dashboard-icon"
                            />
                            <div className="flex flex-col gap-1">
                                <h3
                                    className={`${inter.className} text-sm font-semibold text-dashboard-title`}
                                >
                                    Vendas hoje
                                </h3>
                                <p
                                    className={`${inter.className} text-lg font-bold text-black-400 dark:text-white-400`}
                                >
                                    {vendasDiarias}
                                </p>
                            </div>
                        </div>
                        <div className="p-4 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex items-center gap-6">
                            <IoCard size={20} className="text-dashboard-icon" />
                            <div className="flex flex-col gap-1">
                                <h3
                                    className={`${inter.className} text-sm font-semibold text-dashboard-title`}
                                >
                                    Aprovação cartão
                                </h3>
                                <p
                                    className={`${inter.className} text-lg font-bold text-black-400 dark:text-white-400`}
                                >
                                    {taxaAprovacaoCartao}%
                                </p>
                            </div>
                        </div>
                        <div className="p-4 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex items-center gap-6">
                            <IoDocument
                                size={20}
                                className="text-dashboard-icon"
                            />
                            <div className="flex flex-col gap-1">
                                <h3
                                    className={`${inter.className} text-sm font-semibold text-dashboard-title`}
                                >
                                    Boletos gerados
                                </h3>
                                <p
                                    className={`${inter.className} text-lg font-bold text-black-400 dark:text-white-400`}
                                >
                                   {boletosGerados}
                                </p>
                            </div>
                        </div>
                        <div className="p-4 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex items-center gap-6">
                            <IoPricetag
                                size={20}
                                className="text-dashboard-icon"
                            />
                            <div className="flex flex-col gap-1">
                                <h3
                                    className={`${inter.className} text-sm font-semibold text-dashboard-title`}
                                >
                                    Conversão por boleto
                                </h3>
                                <p
                                    className={`${inter.className} text-lg font-bold text-black-400 dark:text-white-400`}
                                >
                                    {taxaAprovacaoBoleto}%
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-1 flex-col gap-3">
                        <div className="py-2 px-4 bg-white-box dark:bg-black-box rounded-2xl border border-gray-border dark:border-black-300 flex flex-col gap-8">
                            <h3 className={`${inter.className} text-sm font-semibold text-dashboard-title`} >
                                Vendas anuais
                            </h3>
                            <p className={`${inter.className} text-2xl font-bold text-black-400 dark:text-white-400`} >
                                {valorTotal?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </p>
                            <Chart options={optionsLine} series={seriesLine} />
                        </div>
                   
                    </div>
                </div>
            </Container>
        </div>
    );
};

export default DashboardPage;
